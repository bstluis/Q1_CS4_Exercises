package ex05_ele_luisbs;

import java.util.ArrayList;

public class Store {
  private String name;
  private double earnings;
  private ArrayList<Item> itemList;
  private static ArrayList<Store> storeList = new ArrayList();

  public Store(String name){
    this.name = name;
    earnings = 0;
    itemList = new ArrayList<>();
    storeList.add(this);
  }

  public String getName(){
    return name;
  }
  public double getEarnings(){
    return earnings;
  }
  public void sellItem(int index){
    // check if index is within the size of the itemList (if not, print statement that there are only x items in the store)
    // get Item at index from itemList and add its cost to earnings
    // print statement indicating the sale
    if(index < itemList.size()) {
        earnings = earnings + itemList.get(index).getCost();
        System.out.println("\n" + this.getName() + " sold you " + itemList.get(index).getName() + ".\nEarnings: PHP " + earnings + "\n");
    } else {
        System.out.println("Sale Failed\nThere are only " + itemList.size() + " items in " + this.getName() + ". Item No. " + index + " doesn't exist. \n");
    }
  }
  public void sellItem(String name){
    // check if Item with given name is in the itemList (you will need to loop over itemList) (if not, print statement that the store doesn't sell it)
    // get Item from itemList and add its cost to earnings
    // print statement indicating the sale
    int i = 0;
    for(Item a : itemList) {
        i++;
        if(a.getName().equals(name)){
            earnings = earnings + a.getCost();
            System.out.println(this.getName() + " sold you " + a.getName() + ".\nEarnings: PHP " + earnings + "\n");
            break;
        } else if(i >= itemList.size()) {
            System.out.println("Sale Failed\n" + this.getName() + " doesn't sell " + name + ".\n");
        }
    }
  }
  public void sellItem(Item i){
    // check if Item i exists in the store (there is a method that can help with this) (if not, print statement that the store doesn't sell it)
    // get Item i from itemList and add its cost to earnings
    // print statement indicating the sale
    if(itemList.contains(i)){
        earnings = earnings + i.getCost();
        System.out.println(this.getName() + " sold you " + i.getName() + ".\nEarnings: PHP " + earnings + "\n");
    } else {
        System.out.println("Sale Failed\n" + this.getName() + " doesn't sell " + i.getName() + ".\n");
    }
  }
  public void addItem(Item i){
    itemList.add(i);
  }
  public void filterType(String type){
    
    System.out.println("Items with " + type + " tag:");
      int x = 0;
      for(Item a : itemList) {
          if(a.getType().equals(type)) {
              x++;
              System.out.println(x + ". " + a.getName());
          }
      }
  }
  public void filterCheap(double maxCost){
    System.out.println("\nItems with a price of less than or equal to PHP " + maxCost + ": ");
      int y = 0;
      for(Item a : itemList) {
          if(a.getCost() <= maxCost) {
              y++;
              System.out.println(y + ". " + a.getName());
          }
      }
  }
  public void filterExpensive(double minCost){
    System.out.println("\nItems with a price of higher than or equal to PHP " + minCost + ": ");
      int z = 0;
      for(Item a : itemList) {
          if(a.getCost() >= minCost) {
              z++;
              System.out.println(z + ". " + a.getName());
          }
      }
  }
  public static void printStats(){
    int m = 0;
    for(Store name : storeList) {
            m++;
            System.out.println(m + ". " + name.getName() + ": PHP " + name.getEarnings());
        }
  }
}

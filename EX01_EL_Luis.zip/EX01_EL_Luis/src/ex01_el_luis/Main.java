/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex01_el_luis;

/**
 *
 * @author HP Probook
 */
public class Main {
        public static void main(String[] args) {
            Constructor rillaboom = new Constructor("Rillaboom", "Grass", 100);
            Constructor cinderace = new Constructor("Cinderace", "Fire", 80);
            Constructor inteleon = new Constructor ("Inteleon", "Water", 70);

            System.out.println("-- Pokemon 1 --\nName: " + rillaboom.name + "\nType: " + rillaboom.type + "\nHP Stat: " + rillaboom.hpstat + "\n");
            System.out.println("-- Pokemon 2 --\nName: " + cinderace.name + "\nType: " + cinderace.type + "\nHP Stat: " + cinderace.hpstat + "\n");
            System.out.println("-- Pokemon 3 --\nName: " + inteleon.name + "\nType: " + inteleon.type + "\nHP Stat: " + inteleon.hpstat + "\n");
            System.out.print("-- 3 or more Operations --\nSum of the Pokemons' HP Stats: "); Add(rillaboom.hpstat, cinderace.hpstat, inteleon.hpstat); //Sum
            System.out.print("Difference between Rillaboom's and Cinderace's HP Stat: "); Subtract(rillaboom.hpstat, cinderace.hpstat); //Difference
            System.out.print("Inteleon is a Water Type: "); Compare(inteleon.type); //Comparison
        }
        public static void Add(int x, int y, int z){
            int sum;
            sum = x + y + z;
            System.out.println(sum);
        }
        public static void Subtract(int x, int y) {
            int diff; 
            diff = x - y;
            System.out.println(diff);
        }
        public static void Compare(String a){
                System.out.println(a.equals("Water"));
        }
}
package ex04_ele_luisbs;
public class RockPaperScissors{
    public static void main(String[] args){
        Move rock = new Move("Rock");
        Move paper = new Move("Paper");
        Move scissors = new Move("Scissors");

        rock.setStrongAgainst(scissors);
        paper.setStrongAgainst(rock);
        scissors.setStrongAgainst(paper);

        int roundsToWin = 2;
        int action, computerScore, playerScore;
        boolean endGame = false;

        while (endGame == false){
            System.out.println("Welcome to Rock, Paper, Scissors. Please choose an option:\n1. Start game\n2. Change number of rounds\n3. Exit application");
            do {
                action = Input.getInput();
            } while (!(action == 1 || action == 2 || action == 3));

            switch (action){
                case 1:
                    computerScore = 0;
                    playerScore = 0;
                    System.out.println("\nThis match will be first to " + roundsToWin + " wins.");
                    do {
                        int random = (int) Math.floor(Math.random()*3) + 1;
                        Move computerChoice = null;
                        Move playerChoice = null;
                        switch (random) {
                            case 1 -> computerChoice = rock;
                            case 2 -> computerChoice = paper;
                            case 3 -> computerChoice = scissors;
                        }
                        System.out.println("The computer has selected its move. Select your move:\n1. Rock\n2. Paper\n3. Scissors");
                        int moveChoices = Input.getInput();
                        switch (moveChoices) {
                            case 1 -> playerChoice = rock;
                            case 2 -> playerChoice = paper;
                            case 3 -> playerChoice = scissors;
                        }
                        System.out.println("\nPlayer chose " + computerChoice.getName() + "." + " Computer chose " + playerChoice.getName() + ".");
                        switch (Move.compareMoves(playerChoice, computerChoice)) {
                            case 0:
                                playerScore++;
                                System.out.print("Player wins round!\n");
                                break;

                            case 1:
                                computerScore++;
                                System.out.print("Computer wins round!\n");
                                break;

                            case 2: 
                                System.out.print("Round is tied!\n");
                                break;
                        }
                        System.out.print("Player: " + playerScore + " - Computer: " + computerScore + "\n\n"); 

                    } while (playerScore != roundsToWin && computerScore != roundsToWin);

                    if (playerScore == roundsToWin){ 
                        System.out.print("\nPlayer Wins!\n\n");
                    }
                    else {
                        System.out.print("\nComputer Wins!\n\n");
                    }
                    break;

                case 2:
                    System.out.println("\nHow many wins are needed to win a match?");
                    roundsToWin = Input.getInput();
                    System.out.println("\nNew setting has been saved!\n");
                    break;

                case 3:
                    endGame = true;
                    System.out.println("\nThank you for playing!");
                    break;
            }
        }
    }
}
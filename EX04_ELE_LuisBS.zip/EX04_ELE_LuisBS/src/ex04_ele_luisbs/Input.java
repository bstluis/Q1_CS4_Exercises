/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex04_ele_luisbs;

import java.util.Scanner;

/**
 *
 * @author HP Probook
 */
public class Input {
    static Scanner in = new Scanner(System.in);
    public static int getInput() {
        return in.nextInt();
    }
}
